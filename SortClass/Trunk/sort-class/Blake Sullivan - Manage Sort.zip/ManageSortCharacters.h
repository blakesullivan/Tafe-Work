//Blake Sullivan - Manage Sort Characters header
#include <string>
using namespace std;

class ManageSortCharacters
{
private:

public:
	ManageSortCharacters();
	
	void Manage();
	char Input(int);
	int InputOption(string);
	void Display(string);
	void Display(char, char, char);
	void DisplayInFormat(int*);
	void DisplayInFormat(char*);
};