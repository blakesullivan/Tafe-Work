//Blake Sullivan - Manage Sort Characters
#include "ManageSortCharacters.h"
#include "SortCharacters.h"
#include <iostream>
using namespace std;

ManageSortCharacters::ManageSortCharacters()
{
	Manage();
	//system("PAUSE");
}

void ManageSortCharacters::Manage()
{
	if (1==InputOption("What would you like to sort?\n 1. Randomly Generated Lists\n 2. User Entered 3 Characters\n"))
	{
		SortCharacters objSortCharacters;
		if (1==InputOption("How do you want to use this program?\n 1. 1000 Numbers\n 2. 20 Characters\n"))
		{
			objSortCharacters.GenerateRandomNumbers();
			Display("Randomly Generated Numbers:\n");
			DisplayInFormat(objSortCharacters.GetIntArrayPoint(0));
			objSortCharacters.SortIntArray();
			Display("Sorted Numbers:\n");
			DisplayInFormat(objSortCharacters.GetIntArrayPoint(0));
		}
		else
		{
			objSortCharacters.GenerateRandomCharacters(InputOption("What case do you want the characters?\n 1. UPPER CASE\n 2. lower case\n"));
			Display("Randomly Generated Characters:\n");
			DisplayInFormat(objSortCharacters.GetCharArrayPoint(0));
			objSortCharacters.SortCharArray();
			Display("Sorted Characters:\n");
			DisplayInFormat(objSortCharacters.GetCharArrayPoint(0));
		}
	}
	else
	{
		char c1=Input(1);
		char c2=Input(2);
		char c3=Input(3);
		SortCharacters objSortCharacters(c1, c2, c3);
		Display(objSortCharacters.GetCharS1(), objSortCharacters.GetCharS2(), objSortCharacters.GetCharS3());
	}
}

int ManageSortCharacters::InputOption(string sString)
{
	int iTemp;
	bool bExit=false;
	string sInput;
	while (false==bExit)
	{
		cout<<sString;
		getline(cin,sInput);
		const char* cInput = sInput.c_str();
		if (*cInput < '0' || *cInput > '9')
		{
			bExit = false;
			Display("Invalid input, please try again.");
		}
		else
		{
			iTemp = atoi(sInput.c_str());
			if (iTemp > 0 || iTemp < 3)
			{
				bExit=true;
				return iTemp;
			}
			else
			{
				bExit = false;
				Display("Invalid input, please try again.");
			}
		}
	}
}

char ManageSortCharacters::Input(int iTemp)
{
	char cTemp;
	cout<<"Please input a characters. This is Character "<<iTemp<<": ";
	cin>>cTemp;
	return cTemp;
}

void ManageSortCharacters::Display(string sString)
{
	cout<<sString;
}

void ManageSortCharacters::Display(char c1,char c2, char c3)
{
	cout<<"Sorted character order: "<<c1<<", "<<c2<<", "<<c3<<endl;
	system("PAUSE");
}

void ManageSortCharacters::DisplayInFormat(int * iPArray)
{
	int iNum=10;
	for (int i = 0; i <1000 ; i++)
	{
		if ((i+1)%iNum==0)
		{
			cout<<i+1<<"="<<*(iPArray+i)<<endl;
		}
		else
		{
			cout <<i+1<<"="<<*(iPArray+i)<<"	";
		}
	}
	system("PAUSE");
}

void ManageSortCharacters::DisplayInFormat(char* cPArray)
{
	int iNum=10;
	for (int i = 0; i <20 ; i++)
	{
		if ((i+1)%iNum==0)
		{
			cout<<i+1<<"="<<*(cPArray+i)<<endl;
		}
		else
		{
			cout <<i+1<<"="<<*(cPArray+i)<<"	";
		}
	}
	system("PAUSE");
}