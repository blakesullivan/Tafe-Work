//Main Sorting 3 Characters
#include "ManageSortCharacters.h"

int main()
{
	ManageSortCharacters objManage;
	//system("PAUSE");
	return 0;
}