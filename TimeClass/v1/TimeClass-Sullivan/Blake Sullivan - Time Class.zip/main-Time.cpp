//Blake Sullivan - Time Class
#include "Time.h"

int main()
{
	Time objTime;
	system("PAUSE");
	return 0;
}